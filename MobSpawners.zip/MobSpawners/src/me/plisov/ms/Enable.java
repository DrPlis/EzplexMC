package me.plisov.ms;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class Enable extends JavaPlugin implements Listener {

	String prefix = ChatColor.GRAY + "[" + ChatColor.GOLD + "Mob Spawners" + ChatColor.GRAY + "]";
	
	public void onEnable() {
		
	}
	
	public void onDisable() {
		
	}
	
	@SuppressWarnings("deprecation")
	public boolean onBlockBreak(BlockBreakEvent event) {
		Player player = (Player) event.getPlayer();
		Block b = player.getTargetBlock(null, 10);
		if (b == (new ItemStack(Material.STONE))) {
			player.sendMessage(ChatColor.RED + "Test");
		} else {
			player.sendMessage(ChatColor.RED + "Test2");
		}
		return false;
	}
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;
		if (cmd.getName().equalsIgnoreCase("ms")) {
			if (player.hasPermission("ms.use")) {
			if (args.length == 0) {
				player.sendMessage(prefix + ChatColor.RED + " You must specify the mob type!");
				return true;
			}
			
			EntityType type;
			
			try {
					type = EntityType.valueOf(args[0].toUpperCase());
			}
			catch (Exception e) {
				player.sendMessage(prefix + ChatColor.RED + " That is not a valid input!");
				return true;
			}
			
			@SuppressWarnings("deprecation")
			Block b = player.getTargetBlock(null, 10);
			
			if (b == null) {
				player.sendMessage(prefix + ChatColor.RED + " You arn't looking at a spawner!");
				return true;
			}
			
			if (!b.getType().equals(Material.MOB_SPAWNER)) {
				player.sendMessage(prefix + ChatColor.RED + " That isn't a mob spawner!");
				return true;
			}
			
			CreatureSpawner s = (CreatureSpawner) b.getState();
			s.setSpawnedType(type);
			player.sendMessage(prefix + ChatColor.GREEN + " That spawner is now a " + type.toString().toLowerCase() + " spawner");
			
			} else {
			player.sendMessage(prefix + ChatColor.RED + " You do not have access to this command!");
			}
		} 
		return false;
		}
	
}
