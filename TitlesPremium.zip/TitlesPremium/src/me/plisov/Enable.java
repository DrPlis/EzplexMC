package me.plisov;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class Enable extends JavaPlugin implements Listener {

	public void onEnable() {
		ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
	    
	    console.sendMessage("");
	    console.sendMessage(ChatColor.BLUE + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
	    console.sendMessage("");
	    console.sendMessage(ChatColor.AQUA + "  TitlesPremium by plisov ");
	    console.sendMessage(ChatColor.AQUA + "       Version 1.0.0");
	    console.sendMessage("");
	    console.sendMessage(ChatColor.BLUE + "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
	    console.sendMessage("");
		
        getConfig().options().copyDefaults(true);
        saveConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
	}
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event) {
	
	Player player = (Player) event.getPlayer();
    
    //Title
		
    Title title = new Title(getConfig().getString("title"),getConfig().getString("subtitle"),15,200,15);
    title.setTitleColor(ChatColor.RED);
    title.setSubtitleColor(ChatColor.GREEN);
    title.setTimingsToTicks(); // IMPORTANT

    title.send(player);

    if(getConfig().getBoolean("joinmessages", true)) {
	if(!player.hasPlayedBefore()) {
	    String newPlayerJoinMessageSet = getConfig().getString("newplayerjoinmessage").replace("{player}", player.getDisplayName());
	    String coloredNewPlayerJoinMessageSet = ChatColor.translateAlternateColorCodes('&', newPlayerJoinMessageSet);
	    
		event.setJoinMessage(coloredNewPlayerJoinMessageSet); //ChatColor.DARK_GRAY + "[" + ChatColor.GREEN + "+" + ChatColor.DARK_GRAY + "] " + ChatColor.DARK_RED + player.getDisplayName() + ChatColor.RED + " joined.");
	} else if(player.getName().equalsIgnoreCase(getConfig().getString("owner"))) {
		
	    String ownerJoinMessage = getConfig().getString("ownerjoinmessage").replace("{player}", player.getName());
	    String coloredOwnerJoinMessage = ChatColor.translateAlternateColorCodes('&', ownerJoinMessage);
	    
		event.setJoinMessage(coloredOwnerJoinMessage);
	} else if (player.getName().equalsIgnoreCase(getConfig().getString("specialplayer1name"))) {
		String specialplayer1message = getConfig().getString("specialplayer1message").replace("{player}", player.getName());
	    String coloredspecialplayer1 = ChatColor.translateAlternateColorCodes('&', specialplayer1message);
		event.setJoinMessage(coloredspecialplayer1);

		} else {
		//event.setJoinMessage(ChatColor.DARK_GRAY + "[" + ChatColor.GREEN + "+" + ChatColor.DARK_GRAY + "] " + ChatColor.DARK_RED + player.getDisplayName() + ChatColor.RED + " joined.");
	    String joinMessageSet = getConfig().getString("regularplayerjoinmessage").replace("{player}", player.getName());
	    String coloredjoinMessageSet = ChatColor.translateAlternateColorCodes('&', joinMessageSet);
		event.setJoinMessage(coloredjoinMessageSet);
	}
    } else if(getConfig().getBoolean("joinmessages", false)){
		event.setJoinMessage(ChatColor.YELLOW + player.getDisplayName() + " joined the game");
	}
	}
	
	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent event) {
		
	Player player = (Player) event.getPlayer();

	 String newPlayerQuitMessageSet = getConfig().getString("newplayerquitmessage").replace("{player}", player.getName());
	 String coloredNewPlayerQuitMessageSet = ChatColor.translateAlternateColorCodes('&', newPlayerQuitMessageSet);
	
	if(getConfig().getBoolean("quitmessages", true)) {
	if(!player.hasPlayedBefore()) {
		event.setQuitMessage(coloredNewPlayerQuitMessageSet);
		//ChatColor.DARK_GRAY + "[" + ChatColor.RED + "-" + ChatColor.DARK_GRAY + "] " + ChatColor.DARK_RED + player.getDisplayName() + ChatColor.RED + " left.");
	} else if(player.getName().equalsIgnoreCase(getConfig().getString("owner"))) {
	    String ownerQuitMessage = getConfig().getString("ownerquitmessage").replace("{player}", player.getName());
	    String coloredOwnerQuitMessage = ChatColor.translateAlternateColorCodes('&', ownerQuitMessage);
		event.setQuitMessage(coloredOwnerQuitMessage);
	} else {
	    String PlayerJoinMessageSet = getConfig().getString("regularplayerquitnmessage").replace("{player}", player.getName());
	    String coloredPlayerQuitMessageSet = ChatColor.translateAlternateColorCodes('&', PlayerJoinMessageSet);
		event.setQuitMessage(coloredPlayerQuitMessageSet);
	}
	
	} else if(getConfig().getBoolean("quitmessages", false)){
		event.setQuitMessage(ChatColor.YELLOW + player.getDisplayName() + " left the game");
	}
	}
	
	  @SuppressWarnings("unused")
	private String fixColors(String s)
	  {
	    return ChatColor.translateAlternateColorCodes('&', s);
	  }
	
}
