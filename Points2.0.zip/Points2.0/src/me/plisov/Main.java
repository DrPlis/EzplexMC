package me.plisov;

import java.util.HashMap;

public class Main
{
    private static Enable plugin;

    public Main(Enable instance)
    {
        plugin = instance;
    }

    public static HashMap<String, Double> bal = new HashMap<>();

    public static void setBalance(String player, double amount)
    {
        bal.put(player, amount);
    }

    public static Double getBalance(String player)
    {
        return bal.get(player);
    }

    public static boolean hasAccount(String player)
    {
        return bal.containsKey(player);
    }

    public static HashMap<String, Double> getBalanceMap()
    {
        return  bal;
    }

    public static Enable getPlugin()
    {
        return plugin;
    }
}
