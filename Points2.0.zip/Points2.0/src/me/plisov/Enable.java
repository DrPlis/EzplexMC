package me.plisov;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
//import me.plisov.inv.GUI;


public class Enable extends JavaPlugin implements Listener {
	
	public static Enable instance;

    ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
    	public final PlayerJoin pj = new PlayerJoin();
    	public Enable plugin;
    	
    
	String prefix = getConfig().getString("prefix");
	String coloredprefix = ChatColor.translateAlternateColorCodes('&', prefix);
	FileConfiguration config;
	FileConfiguration setup;
	File cfile;

	public ArrayList<UUID> muted = new ArrayList<>();
	
	
	public final HashMap<UUID, Location> lastLocation = new HashMap<UUID, Location>();
	
	public static final Logger log = Logger.getLogger("Minecraft");
	
    public void onEnable() {
    	
    	instance = this;

    	//Bukkit.getServer().getPluginManager().registerEvents(new GUI(this), this);

    	getCommand("sp").setExecutor(new EconCommand());
        new Main(this);
        SLAPI.loadBalances();
         Bukkit.getPluginManager().registerEvents(new PlayerJoin(), this);
         
        ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
        console.sendMessage(ChatColor.RED + " =-=-=-=-=-=-=-=-=-=-=-=-=");
        console.sendMessage(ChatColor.GREEN + "         Points");
        console.sendMessage(ChatColor.GREEN + "       Created by");      
        console.sendMessage(ChatColor.DARK_RED + "      plisov");
        console.sendMessage(ChatColor.GREEN + "      Version: 1.0");
        console.sendMessage(ChatColor.RED + " =-=-=-=-=-=-=-=-=-=-=-=-=");
        
}
    
    public void onDisable() {
    	instance = null;
   	 	SLAPI.saveBalances();
    }
    
    int countdown;
	public int i = 10;
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;
//		
		Double playerBalance = Main.getBalance(player.getName());
	    String pointsmessage = getConfig().getString("pointsmessage");
	    String coloredpointsmessage = ChatColor.translateAlternateColorCodes('&', pointsmessage);
		if (cmd.getName().equalsIgnoreCase("points")) {
			if (player.hasPermission("sp.checkpoints")) {
			if(playerBalance == null) {
			player.sendMessage(coloredprefix + coloredpointsmessage + "0");
			} else if(!(playerBalance == null)) {
			player.sendMessage(coloredprefix + coloredpointsmessage + playerBalance);
			}
			} else {
				player.sendMessage(coloredprefix + ChatColor.DARK_RED + "You do not have access to this command!");
			}
		}
		return false;
			
	}
	public static Enable getInstance(){
		  return instance;
		 }
	
	
	}
