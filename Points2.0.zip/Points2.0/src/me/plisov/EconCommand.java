package me.plisov;

import java.io.File;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class EconCommand implements CommandExecutor, Listener {
	FileConfiguration config;
	File cfile;
    ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
	 String prefix = ChatColor.GOLD + "[" + ChatColor.AQUA + "PremiumPoints" + ChatColor.GOLD + "] ";
	 
	 
    @Override
    public boolean onCommand(CommandSender cs, Command command, String s, String[] args) {
    	Player player = (Player) cs;
    	if(player.hasPermission("sp.givepoint")) {
            if(args.length == 0) {
                cs.sendMessage(prefix + ChatColor.RED + ChatColor.BOLD + " Hey! You cannot use that commnad like that!");
                cs.sendMessage(prefix + ChatColor.GREEN + ChatColor.BOLD + " Usage: /sp" + ChatColor.RED + ChatColor.BOLD + " <add/remove/set> <player> <amount> <reason>");
                return true;
            }
            
            if(args.length == 1) {
            	cs.sendMessage(prefix + ChatColor.RED + ChatColor.BOLD +  "You must enter a player's name!");
            	cs.sendMessage(prefix + ChatColor.GREEN + ChatColor.BOLD + " Usage: /sp <add/remove/set>" + ChatColor.RED + ChatColor.BOLD + " <player> <amount> <reason>");
            	return true;
            }
            
            if(args.length == 2) {
            	cs.sendMessage(prefix + ChatColor.RED + ChatColor.BOLD +  "You must enter an amount!" + ChatColor.DARK_RED + ChatColor.BOLD + " (Do not give out more than one unless its a refund)");
            	cs.sendMessage(prefix + ChatColor.GREEN + ChatColor.BOLD + " Usage: /sp <add/remove/set> <player>" + ChatColor.RED + ChatColor.BOLD + " <amount> <reason>");
            	return true;
            }
            
            if(args.length == 3) {
            	cs.sendMessage(prefix + ChatColor.RED + ChatColor.BOLD + "You must enter a reason!");
            	cs.sendMessage(prefix + ChatColor.GREEN + ChatColor.BOLD + " Usage: sp <add/remove/set> <player> <amount> " + ChatColor.RED + ChatColor.BOLD + "<reason>");
            	return true;
            }
        if(args[0].equalsIgnoreCase("add")) {
        	if(player.hasPermission("sp.addpoint")) {
            if(!Main.hasAccount(args[1])) {
                cs.sendMessage(ChatColor.RED+"Error: Could not find player. (CaSe SeNsItIvE");
                return true;
            }
            double amount = 0;
            try
            {
                amount = Double.parseDouble(args[2]);
            }catch (Exception e)
            {
                cs.sendMessage(ChatColor.RED+"");
                return true;
            }
            Main.setBalance(args[1], Main.getBalance(args[1]) + amount);
            
            String reason = "";
            for (int i = 3; i < args.length; i++) {
            reason = reason + args[i] + " ";
            }
            
            Bukkit.getServer().broadcastMessage(ChatColor.GREEN + "(!) " + ChatColor.RED + player.getName() + ChatColor.LIGHT_PURPLE + " gave " + ChatColor.RED + args[1] + 
            ChatColor.LIGHT_PURPLE + " a point for " + ChatColor.GREEN + reason);
            Enable plugin = Main.getPlugin();
			Bukkit.getServer().getPluginManager().disablePlugin(plugin);
            Bukkit.getServer().getPluginManager().enablePlugin(plugin);
            Double playerBalance = Main.getBalance(player.getName());
        	
            //Main.setBalance(args[1], Main.getBalance(args[1]) + amount);
            //Bukkit.getServer().broadcastMessage(prefix + ChatColor.GREEN + " A point has been given to " + args[1]);
            //Bukkit.getServer().broadcastMessage(ChatColor.RED + "(Total points given: " + ChatColor.GREEN + args[2] + ChatColor.RED + ")");
            //Bukkit.getServer().broadcastMessage(ChatColor.GOLD + "Point given by " + ChatColor.RED + player.getDiS.P.layName());
            //Bukkit.getServer().broadcastMessage(ChatColor.GOLD + "Reason: " + ChatColor.AQUA + args[3]);
        	} else {
        		player.sendMessage(ChatColor.DARK_RED + "You are not allowed to add points!");
        		return false;
        	}
        }else if (args[0].equalsIgnoreCase("remove"))
        {
        	if(player.hasPermission("sp.removepoint")) {
            if(!Main.hasAccount(args[1]))
            {
                cs.sendMessage(ChatColor.RED+"Error: Player does not have an account");
                return true;
            }
            double amount = 0;
            try
            {
                amount = Double.parseDouble(args[2]);
            }catch (Exception e)
            {
                cs.sendMessage(ChatColor.RED+"You gotta enter in a number bro");
                return true;
            }
            
            String reason = "";
            for (int i = 3; i < args.length; i++) {
            reason = reason + args[i] + " ";
            }

            Main.setBalance(args[1], Main.getBalance(args[1]) - amount);
            cs.sendMessage(ChatColor.RED + "Removed S.P. from player");
            Bukkit.getServer().broadcastMessage(ChatColor.LIGHT_PURPLE + "(!) " + player.getName() + ChatColor.LIGHT_PURPLE + " removed a point from " + ChatColor.LIGHT_PURPLE + args[1] + 
                    ChatColor.LIGHT_PURPLE + " for " + ChatColor.GOLD + reason);
            Enable plugin = Main.getPlugin();
            Bukkit.getServer().getPluginManager().disablePlugin(plugin);
            Bukkit.getServer().getPluginManager().enablePlugin(plugin);
            Double playerBalance = Main.getBalance(player.getName());
        	
            //Bukkit.getServer().broadcastMessage(prefix + ChatColor.GREEN + " A point has been removed from " + args[1]);
            //Bukkit.getServer().broadcastMessage(ChatColor.RED + "(Total points taken: " + ChatColor.GREEN + args[2] + ChatColor.RED + ")");
            //Bukkit.getServer().broadcastMessage(ChatColor.GOLD + "Points taken by " + player.getDiS.P.layName());
            //Bukkit.getServer().broadcastMessage(ChatColor.GOLD + "Reason: " + ChatColor.AQUA + args[3]);
        	} else {
        		player.sendMessage(ChatColor.DARK_RED + "You do not have access to remove points!");
        		return false;
        	}
        }else if (args[0].equalsIgnoreCase("set"))
        {
        	if(player.hasPermission("sp.setpoints")) {
            if(!Main.hasAccount(args[1]))
            {
                cs.sendMessage(ChatColor.RED+"Error: Player does not have an account");
                return true;
            }
            double amount = 0;
            try
            {
                amount = Double.parseDouble(args[2]);
            }catch (Exception e)
            {
                cs.sendMessage(ChatColor.RED+"You gotta enter in a number bro");
                return true;
            }
            Main.setBalance(args[1], amount);
            cs.sendMessage(ChatColor.GREEN + "Set players' points");
        	} else {
        		player.sendMessage(ChatColor.DARK_RED + "You do not have acces to set points!");
        		return false;
        	}
        }else
        {
            cs.sendMessage(ChatColor.RED+"Incorrect argument");
        }
    	} else {
        	console.sendMessage(ChatColor.RED + "Player did not have permission!");
        	player.sendMessage(prefix + ChatColor.GRAY + "This requires Permission Rank [" + ChatColor.BLUE + "ADMIN" + ChatColor.GRAY + "]");
			return false;
    	}
        return true;
    }
    
    
    	
}
