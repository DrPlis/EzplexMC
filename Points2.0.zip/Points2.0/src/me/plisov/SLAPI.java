package me.plisov;

public class SLAPI
{
    private static Enable plugin = Main.getPlugin();

    public static void saveBalances()
    {
        for(String p : Main.getBalanceMap().keySet())
        {
            plugin.getConfig().set("balance."+p, Main.getBalanceMap().get(p));
        }
        plugin.saveConfig();
    }

    public static void loadBalances()
    {
        if(!plugin.getConfig().contains("balance")) return;
        for(String s : plugin.getConfig().getConfigurationSection("balance").getKeys(false))
        {
            Main.setBalance(s, plugin.getConfig().getDouble("balance."+s));
        }
    }
}
